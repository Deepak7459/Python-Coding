# Write a program to find max and min in a set.
a = {12,45,56,80,75,157,0,1}
maximum = max(a)
minimum = min(a)
print("The maximum value in the set is",maximum)
print("The minimum value in the set is",minimum)


# Write a programto find common element in three list using sets.
a = [1,5,6,8,2]
b = [4,5,6,7]
c = [1,9,6,2,5]
print(set(a)&set(b)&set(c))
print("The common elements in the given three lists are",set(a)&set(b)&set(c))

# Write a python program to remove an item from a set if it is present in the set.
a = [1,5,6,8,2]
a.remove(8)
print(a)

# Write a python Program to check if a set is a subset of another set.
a= {1,2,3,4,5,6}
b = {2,3,4}
print(b.issubset(a))