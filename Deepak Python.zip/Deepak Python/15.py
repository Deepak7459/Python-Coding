# Nested Loop.
for i in range(1,4):
 for j in range(1,11):
    print(j,end = " ")
    print()