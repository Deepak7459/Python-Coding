#sets for intersection.
    set1 = {1,2,3}
    set2 = {2,3,4}
    print(set1.intersection(set2))