# Sets Function part - 2.
a = {"Ironman","Hulk","Thor","Captain America"}
b = {"Superman","Batman","Wonder-Women"}
c ={"Hulk","Thor"}

# is disjoint.
print(a.isdisjoint(b))  # True
print(b.isdisjoint(b))  # False

# Issubset.

print(c.issubset(a))


# ISsuperset.
print(b.issuperset(a))
print(b.issuperset(c))

# Update.
x = a.update(b)
x = a.update(c)
print(x)

# clear.
a.clear()
print(a)
