# wap to enter marks of 3 subjects from the user and store them in a dictionary ,start with an empty dictionary and add one by one . use subject name as a key and marks as value.
mark = {}
x= int(input{"enter physics:"})
mark.update({"physics": x})
x=int(input{"maths:"})
mark.update({"math": x})
x=int(input{"chemistery":})
mark.update({"chemistery":x})
print(mark)