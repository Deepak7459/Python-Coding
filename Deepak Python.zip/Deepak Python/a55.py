# Dictionay functions.
student = {"name":"Deepak","class":"4th year","roll_no":20}
# get.
x = student.get("name")
print(x)


#Items.
a = student.items()
print(a)


# Keys.
b = student.keys()
print(b)


# values.
c = student.values()
print(c)

# copy.
d = student.copy()
print(d)

# set default.
x = student.setdefault("roll_no",24)
print(x)