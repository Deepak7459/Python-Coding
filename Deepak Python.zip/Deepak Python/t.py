#Loops in python 
'''count=1
while count<=5:
    print("hello")
    count+=1
i=1
while i<=5:
        print("Deepak Singh")
        i+=1'''
    
  # print numbers from 1 to 5.
i=1
while i<=5:
  print(i)
i +=1
print("loop ended")