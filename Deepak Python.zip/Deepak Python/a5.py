# If elif else Statement.
marks = 85
if marks>=90:
    print("you can go to a trip")
elif marks>=80 and marks<90:
    print("you will get a new phone")
elif marks>=70 and marks<80:
    print("you will get a new book")
else:
    print("you will not get back your phone")
    