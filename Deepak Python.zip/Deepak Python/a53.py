# Access the nested ky "marks" from the following nested data.
import json
student_data = """{"student":
                {"grade":
                    {"name":"David","marks":87
                     }
                }
                }"""
data = json.loads(student_data)
print(data["student"]["grade"]["marks"])