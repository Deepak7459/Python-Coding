# Alng with range and length in for loop.
a = ("one plus","vivo","redmi","oppo","samsung")
for i in range(len(a)):
    print(a[i])
    
    
# Along with while loop.
i = 0
while i <len(a):
    print(a[i])
    i += 1