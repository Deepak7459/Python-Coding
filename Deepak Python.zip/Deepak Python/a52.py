# Sort the following json keys and write them into a file.
import json
student_data = {"name":"Deepak", "age":"23","marks":"80"}
f = open("demo.json","w")
data = json.dumps(student_data , indent = 4, sort_keys = True)
f.write(data)
print("The data has been added to the file")