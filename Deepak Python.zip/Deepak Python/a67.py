# Write a python function to create and print a list where the values are square of number between 1 and 30.
def create_list():
    l = []
    for i in range(1,31):
        l.append(i**2)
        return l
    print(create_list())