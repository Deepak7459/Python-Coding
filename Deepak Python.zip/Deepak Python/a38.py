# Write a program to removedot(.) from the following string.
z = "F.R.I.E.N.D.S"
b = z.replace("."," ")
print(b)

# Write a program to check the number of occurance of a substring in a string.
a = "She sells sea shells on the sea shore"
b = a.count("sea")
print(b)