#Write a program to take an user input as integer then convert it to float.

a = int(input("Enter a number here :"))
print(a)
print(type(a))
a = float (a)
print("after conversion",a)
print(type(a))