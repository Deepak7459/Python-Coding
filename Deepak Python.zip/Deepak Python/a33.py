# String Functions Part - 2.


# endswith() - Returns True if the string ends with the specified value.
a = "Deepak Singh"
print(a.endswith("n",6,9))

# stratswith() - Returns True if the  string start with the specified value.
a = "Harry potter"
print(a.startswith("p",6,9))

# swapcase() - Swap case , lower case becomes upper case amd vice versa.
a = "Harry potter"
print(a.swapcase())

# strip() - Returns a trimed version of the string.
a = "Harry potter"
print(a.strip())


# split() - split the string at the specified seprator andreturns a list.
a = "#OOF #BRB#OMD#IB"
b = "hello. My name is Jhon. iam 23 years old"
print(a.split("#"))
print(b.split("#"))

#ljust()- Returns a left justified version of the string.
a = "Harry potter"
b = a.ljust(23,"*")
print(b,"is my favourite movie")


# rjust() - Returns to a right justified version of the string.
a = "Harry Potter"
b = a.rjust(25)
print(b,"is my favourite movie")

# replace() - Returns a string where a specified value is replaced with a specified value.
a = "My name is Deepak"
print(a)
print(a.replace("Deepak","Varun"))

# rindex - searches the string for a specified value and returns the last poition of the string where it was found.
a = "Harry potter and the prisoner of azkaban"
print(b.rindex("Harry"))


# rfind() - searches the string for a specified value and returns the last position of the string where it was found.
a = "Harry potter and the goblet of fire"
print(a.rfind("goblet"))