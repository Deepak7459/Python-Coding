# Break and Continuestatement.
#Continue.
'''for i in range(1,11):
    if i == 5:
        continue
else:
    print(i)
    '''
    
    #             OR
    #Break.
for i in range(1,11):
    if i == 5:
        break
else:
    print(i)