print("Hello World")
print(7)
print("Bye")
print(17*15)


