a = "hellol"
b = "Hello 123"
c = "123456"
d = "HELLO"
e = "  "
f = "Hello 123@"
g = "1.234"

# isalnum - Returns True if all charecrtors in the string are alphanumeric.
print(a.isalnum())
print(b.isalnum())
print(c.isalnum())
print(d.isalnum())
print(e.isalnum())
print(f.isalnum())
print(g.isalnum())



# isalpha - Returns True if all charectors in the string are aphabet.
print(a.isalpha())
print(b.isalpha())
print(c.isalpha())
print(g.isalpha())



# isdecimal - Returns True if all charactors in the string are decimals.
print(a.isdecimal())
print(b.isdecimal())
print(c.isdecimal())
print(g.isdecimal())



# isdigit- Returns True if all the charactors in the string are digit.
print(a.isdigit())
print(c.isdigit())
print(e.isdigit())
print(f.isdigit())
print(g.isdigit())


# isnumeric - Returns True if all the charactors in the string are numeric.
print(a.isnumeric())
print(b.isnumeric())
print(c.isnumeric())
print(e.isnumeric())
print(g.isnumeric())


# islower - Returns True ifall the charactors in the string are Lower Case.
print(a.islower())
print(b.islower())
print(c.islower())
print(e.islower())
print(g.islower())


# isupper - Returns True if all the charactors in the string are Upper Case.
print(a.isupper())
print(b.isupper())
print(c.isupper())
print(e.isupper())
print(g.isupper())


# isspace- Returns True if all the Charactors in the string are white space.
print(a.isspace())
print(b.isspace())
print(d.isspace())
print(f.isspace())
print(g.isspace())




# istittle - Return True if the string follows the rules.
print(a.istitle())
print(b.istitle())
print(d.istitle())
print(e.istitle())
print(g.istitle())