# Write a program to take details from a students for ID - Cards  and then print it in different line.


name = input("Enter the name of a student :")
grade = input("Enter the grade of a student :")
age = input("Enter the age of a student :")
email = input("Enter the email of a student :")
ph_no = input("Enter the ph_no of a student :")

print("Student Identity Card")
print("Name:",name)
print("Grade:",grade)
print("Age:",age)
print("Email:",email)
print("Ph_no:",ph_no)