# While true.
while True:
    num1 = int(input("Enter a number here:"))
    num2 = int(input("Enter a number here:"))
    
    print(num1 + num2)
    repeat = input("Do you want to stop the program")
    if repeat == "Yes":
        break