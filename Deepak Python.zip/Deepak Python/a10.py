# Write a program check whether the passed letter is a vowel or not.
letter = input("Enter a letter here:")
if letter in "aeiouAEIOU":
    print("the letter is a vowel")
    
else:
    print("The letter is consonant")