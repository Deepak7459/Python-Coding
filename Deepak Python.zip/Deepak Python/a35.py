# Write a program to check if a number is prime or not.
a = int(input("Enter the number here:"))

if a<=1:
    print("it is not a prime number")
else:
    for i in range(2,a):
        if a% i == 0:
            print("it is not a prime nummber")
            break
        else:
            print("it is a prime number")