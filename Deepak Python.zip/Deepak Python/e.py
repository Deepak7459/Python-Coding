# Conditional Statements.
age=25

if age >=20:
    print("can vote and apply for licence")
    print("can drive")