# for loop.
'''nums=[1,2,3,4,5]

for val in nums:
    print(val)'''
    
'''veggies = ["potato","brinjal","ladyfinger","cucumber"]
for val in veggies:
    print(val)
    
    
tup = (1,2,3,4,5,6)

for num in tup:
    print(num)'''
    
str = "Deepak Singh"

for char in str:
    print(char)