# Write a program to find the accurrance of $ in a strig.
str="Hii ,$ I am the $ symbol $ 99.99"
print(str.count("$"))