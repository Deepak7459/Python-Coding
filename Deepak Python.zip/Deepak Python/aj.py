# WAP to find sum of first n numbers. (using while).

'''n = 5

sum = 0

for i in range (1,n+1):
    sum +=i
    print("total sum =", sum)'''
    
    
    
#   while.
'''n = 5
sum  = 0
i = 1
while i<= n:
    sum += i
    i += 1
    print("total sum =", sum)'''



#WAP to find the factorial of first n numbers.(usinf for).


n = 5

fact = 1

for i in range(1,n+1):
    fact *= 1
    print("factorial = ", fact)
