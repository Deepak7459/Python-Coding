first=int(input("enter first:"))
second=int(input("enter second"))
print("sum=",first + second)