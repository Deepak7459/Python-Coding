# COnvert the following dictionary into JSON format.
#student_date = {"name":"Deepak","age":"23","marks":"80"}

import json

student_date = {"name":"Deepak","age":"23","marks":"80"}
print(type(student_date))

data = json.dumps(student_date)
print(data)
print(type(data))

# Access the value of age from the given data json date.
# student_date = {"name":"Deepak","age":"23","marks":"80"}

student_date = {"name":"Deepak","age":"23","marks":"80"}
data = json.loads(student_date)
print(data["age"])