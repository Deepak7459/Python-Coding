# Write a program to create a billing system at supermarket.
while True:
    name = input("Enter costomer's name:")
    total = 0
    
    while True:
        print("Enter the amount and quantity")
        amount=float(input("Enter amount:"))
        quantity=float(input("Enter quantity:"))
        total += amount * quantity
        repeat = input("Do you want to add more items ?(yes/no):")
        if repeat=="no"or repeat == "No":
            break
        print("-"*40)
        print("Name",name)
        print("amount to be paid:",total)
        print("-"*40)
        print("****Thank you for shopping with us****")
        repeat = input("Do you want to continue billing for another customer ?(yes/no):")