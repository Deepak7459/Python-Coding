# Write a program to find maximum number of three numbers in python.
def maximum_num (val1,val2,val3):
    if val1>val2 and val1>val3:
        print(val1,"IS the gratest number")
    elif val2>val1 and val2>val3:
        print(val2,"IS the gratest number")
    else:
        print(val3,"IS the greatest number")


maximum_num(12,5,9)  


