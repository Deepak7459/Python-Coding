
age = 21
if(age>=18):
    
    print("can vote and apply for licence")
