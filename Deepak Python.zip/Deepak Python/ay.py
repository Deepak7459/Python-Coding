# Write a program to swap two variables.
'''x = 12
y = 13
temp = x
print(temp)
x = y
print(x)
y = temp
print(y)
print("value of x is",x)
print("value of y is ",y)   '''
     
     
     
     
     
#                      or
'''x = 12
y = 13
x,y = y,x
print(x)
print(y)'''

#                    Or
a = input("Enter the value of a :")
b = input("Enter the value of b :")
# Displayinng before swapping.
print(f"Before Swapping : a = {a}, b = {b}")
# Swapping using a temporary variable.
temp = a
a = b
b = temp
# Display after swapping.
print(f"After Swapping : a = {a},b = {b}")