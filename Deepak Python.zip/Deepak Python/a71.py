# Modules.
# DateTimeModules.
import datetime
x = datetime.datetime.now()
print(x)




y = datetime.datetime(2002,11,6)
print(y.strftime("%A"))



# Random modules.
import random
x = random.randint(1,10)
print(x)

l = ["Heads","Tails"]
x = random.choice(l)
print(x)



# Maths Module.
import math
x = max(13,12,5,7,59)
print("The maximum value is",x)


y = min(14,54,12,5,8,6)
print("The minimum value is",y)

a = pow(2,4)
print(a)

b = math.sqrt(49)
print(b)


c = abs(-12.345*3)
print(c)


d = math.ceil(2.4)
print(d)

e = math.floor(2.4)
print(e)