# Write a program to get fibonacci series up to 10 numbers.
'''a = 0
b = 1
n = int(input("Enter the number here:"))
if n==1:
    print(1)
else:
    print(a)
    print(b)
    for i in range(2,n):
        c = a + b
        print(c)
        a = b
        b = c
        print(c)'''
        
        
a = 0
b = 1
print(a)
print(b)
for i in range(1,11):
    c = a + b
    a = b
    b = c
    print(c)
    
