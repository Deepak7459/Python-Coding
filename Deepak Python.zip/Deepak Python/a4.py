# IF else statement.
marks = 87
if marks >=90:
    print("you will get a phone")
else:
    print("no phone for one week")
    
    print("Thank you")