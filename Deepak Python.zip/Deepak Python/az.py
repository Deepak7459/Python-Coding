# Write a program to convert a float into integer.
x = 12.5
print(type(x))
x = int(x)
print(type(x))
print(x)