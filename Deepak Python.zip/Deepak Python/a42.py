# Write a program to check if aevery words in a string beging with a capital letter.
a = input("Enter anything here")
print(a.istitle())
