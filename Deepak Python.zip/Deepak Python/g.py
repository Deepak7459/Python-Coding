'''Grade student based on marks
marks >=90,grade="A"
90> marks >=80,grade="B"
80> marks >70 , grade="C"
70> marks >,grade = "D"'''
# Input: Get marks from the user
marks = float(input("Enter the student's marks: "))

# Grading logic using conditional statements
if marks >= 90:
    grade = "A"
elif marks >= 80:
    grade = "B"
elif marks > 70:
    grade = "C"
else:
    grade = "D"

# Output the result
print("Grade:", grade)
