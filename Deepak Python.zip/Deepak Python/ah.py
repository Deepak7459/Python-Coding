# Print nummbers from 1 to 100.
'''for i in range(101):
    print(i)'''
    
# Print numbers from 100 to 1.
'''for i in range(100,0,-1):
    print(i)'''
  
# Print the multiplication table of a number n.


n = int(input("enter the number :"))

for i in range(1,11):
    print(n*i)
  
