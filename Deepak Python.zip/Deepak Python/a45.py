# List Comprihensions.
l1 = [20,30,40,50,60]
l2 = []
for i in l1:
 l2.append(i)
print(l2) or print(l1,"\n",l2)

l3 = [i for i in l1]
print(l3)