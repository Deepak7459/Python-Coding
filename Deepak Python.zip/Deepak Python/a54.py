student = {"name":"Deepak", "class":"6th","roll_no":23}
# Printing all the key names one by one.
for x in student:
    print(x)
    
# Printing all the values names one by one.
for x in student:
    print(student[x])
    
# using value function.
for x in student.values():
    print(x)
    
    
# Using item function.
for x,y in student.items():
    print(x,":",y)
    