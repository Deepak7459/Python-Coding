#Pass Statement.

for i in range(5):
    pass
print("Some usefull work")