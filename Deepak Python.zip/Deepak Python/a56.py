# Nested dictionaries.
Employes= {1:{"Name":"Deepak","Age":22,"Gender":"Male"},
           2:{"Name":"Dipa","Age":21,"Gender":"Female"},
           3:{"Name":"Rani","Age":20,"Gender":"Female"}}
print(Employes)
print(Employes[2]["Age"])
print(Employes[3])