#Write a program to find the length of the followint string.
'''a = "Why fit in, when you are Born to stand out !"
b = (len(a))
print("The length of the given string is:",b)'''


#Write a program to check how many times alphabet o is occuring.
a = "Why fit in, when you are Born to stand out !"
print(a.count("o"))  



#   Write a program to convert the whole string into lower and upper cases.
a = "Why fit in, when you are Born to stand out !"
x = a.lower()
print(x)
y = a.upper()
print(y)


# Write a program to convert the following string into a tittle.
a = "Why fit in, when you are Born to stand out !"

z = a.title()
print(z)



# Write a program to find the index number of "fit in".
a = "Why fit in, when you are Born to stand out !"
print(a.find("fit in"))