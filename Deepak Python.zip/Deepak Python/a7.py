# Write a program to check if a number is positive.
num = int(input("Enter the number here :"))
if num >0:
    print("it is positive")