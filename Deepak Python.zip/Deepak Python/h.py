#write a program to find the greatest of 3 numbers entered by the users.
a = int(input("enter the first number :"))
b = int(input("enter the second number :"))
c = int(input("enter the third number :"))
if(a>=b and a>=c):
    print("first number is largest",a)
elif (b>=c):
    print("second number is largest",b)
else:
    print("third numer is largest",c)