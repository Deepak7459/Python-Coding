# wap to check if a number is a multiple of 7 or not.
x = int(input("enter the number :"))
if(x%7==0):
    print("multiple of 7")
else:
    print("not a multiple")