# IF the Statement.
marks = 87
if marks >= 90 :
    print("you will get a mobile phone")
    print("Thank you")