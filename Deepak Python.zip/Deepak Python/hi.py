n = 91
reverse = int(str(n)[ :: -1])
print(reverse)