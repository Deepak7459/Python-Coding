# WAP to input user's first name and print it' Length.
name = input("enter your name:")

print("Length of your name is",len(name))