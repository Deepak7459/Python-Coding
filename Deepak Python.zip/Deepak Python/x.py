#print the multiplication table of a number n.
'''i=1
while i<=10:
    print(3*i)
    i+=1'''
    
n=int(input("enter number"))
i=1
while i<=10:
    print(n*i)
    i+=1