light="red"

if light=="red":
    print("stop")
elif light== "green":
    print("go")
elif light=="yellow":
    print("look")
    print("end of code")