# Store following word meanning in python dictionary.
dictionary = {
    "cat":"a small animal"
    "table": ["a piece of furniture","list of facts and figures"]
}
print(dictionary)