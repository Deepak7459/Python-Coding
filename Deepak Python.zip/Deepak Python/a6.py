# Nested if statement.

marks = 790
if marks >=80:
    print("You will get a new phone")
if marks >=95:
    print("You will go to a trip")
else:
    print("NO phone for a month")