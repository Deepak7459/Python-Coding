#print numbers from 1 to 100.
i=1
while i<=100:
    print(i)
    i+=1