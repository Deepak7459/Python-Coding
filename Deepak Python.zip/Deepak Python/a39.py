# Take an input from user as a string then , reverse it.
a = input("Enter anything here:")
print(a[: : -1])


# Write a program to check if a string contains only digits.
a = input("Enter anything here:")
b = (a.isdigit())
if b==True:
    print("it contains only digits")
else:
    print("it does not contain only digits")
    