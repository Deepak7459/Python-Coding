# List Functions.
a = ["Hulk","Thor","Ironman","capton America","missmarvel"]
# To find the length of a string.
print(len(a))


# to count an occurance of a particular element.
print(a.count("Thor"))


# To add to the list.
a.append("Black Panther")
print(a)

# to add a specific location.
a.insert(2,"vision")
print(a)



# To remove from a list.
a.remove("vision")
print(a)


# To remove from a certain location.
print(a.pop(1))
print(a)



# To create a copy of a list.
b = a.copy()
print(b)


# To access an element.
print(a.index("Ironman"))



# To entent the list.
c = ["Gamora","Star Lord"]
a.extend(c)
print(a)

# To reverse the list.
a.reverse()
print(a)



# TO sort the list.
a.sort()
print(a)


# To clear all the data from the list.
a.clear()
print(a)



