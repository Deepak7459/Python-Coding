# Set in python.
set1= {1,2,3}
set2 = {2,3,4}
print(set1.union(set2))
print(set1)
print(set2)