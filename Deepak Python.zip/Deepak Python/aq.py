# OOPs in python.
'''class Student:
    name = "Deepak"
    
# Create object (instance)
s1 = Student()
print(s1.name)'''

class Car:
    color = "blue"
    brand = "BMW"
    
car1 = Car()
print(car1.color)
print(car1.brand)
