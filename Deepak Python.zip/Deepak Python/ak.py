# Function in python.
'''def cal_sum(a,b):
    sum=a+b
    print(sum)
    return sum

cal_sum(5,20)


cal_sum(3,5)


cal_sum(4,10)'''



'''def cal_sum(a,b): #parameters.
    
    return a + b

sum = cal_sum(2, 3) #function call;arguments
print(sum)'''

# average of 3 numbers.
def cal_avg(a,b,c):
    sum = a+b+c
    avg = sum / 3
    print(avg)
    return avg


cal_avg(1,2,3)