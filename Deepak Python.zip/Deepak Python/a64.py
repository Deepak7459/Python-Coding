# Function.
def add():
    x = 56
    y = 23
    print(x+y)
    add()
    
    
# Parameters and Arguments.
def add(x,y):
    print(x + y)
    add(45,76)
    add(12,14)
    
    
    
def rect(length,width):
    print("The area of the rectangle  is",length*width)
    rect(1,2,3)
    
# Arbitary argument.
def hello(name):
    print("hello,My name is ",name)
    hello("Deepak")
    
