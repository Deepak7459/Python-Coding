# Conversion.
a = 123
b = 1.23
print(type(a))
print(type(b))
c = a+b
print(c)
print(type(c))