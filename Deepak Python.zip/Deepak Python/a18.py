# Write a program to find a sum of all the even nummbers upto 50.
sum = 0
for i in range(1,51):
    if i % 2 == 0:
        sum +=i
        print("The sum of all the even numbers upto 50 is:", sum)