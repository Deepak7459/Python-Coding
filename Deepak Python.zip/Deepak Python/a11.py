#Write a program to check if a number is a single digit number ,two number and so on .....,up to 5 digits.
print("**** NUMBER DIGIT CHECKER ****")
num = int(input("Enter a number here upto 5 digits:"))
if num >=0 and num <=9:
    print("THe number is  a single digit number")
    
elif num >=10 and num <=99:
    print("The number is a two digit number")
    
elif num >=100 and num <=999:
    print("The number is a three digit number")
    
    
elif num>=1000 and num<=9999:
    print("The number id a four digit number")
    
    
elif num >=10000 and num <=99999:
    print("The number is a five digit number")
    
else:
    print("The number is more than five digits")