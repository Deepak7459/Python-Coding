# Write a program to swap first and fourth elements.
a = ["Deepak","rahul","Vansh","Dipa","Varun"]
a[0],a[3] = a[3],a[0]
print(a)

# Write a program to add a new value at second position.
a.insert(1,"Arjuna")
print(a)

# Write a program to delete a value from 3rd position.
a.pop(2)
print(a)

# Write a program to multiply all the numbers in the list.
b = [13,15,20,25]
mul = 1
for i in b:
    mul *= i
    print(mul)
    
    
# Write a program to get the largest number from the list.
b.sort()
print(b)
print("The largest value in the given list is:", b[-1])
print("The smallest value in the given list is:", b[0])

# Write a program to get the smallest number from the list.
b.sort()
print(b)
print("The smallest value in the given list is:", b[0])