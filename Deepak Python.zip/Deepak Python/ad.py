# For loop with else.
'''str = "Deepak Singh"
for char in str:
    print(char)
else:
    print("End")'''
    
    
str = "Deepak Singh"
for char in str:
   if(char == "p") :
       print("p Found")
       break
   print(char)
else:
    print("End")