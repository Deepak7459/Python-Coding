#Dictionary.
info = {
    "name" : "apnacollege",
    "subject" : ["python", "C","Java"],
    "topics":("dict","set"),
    "age": 35,
    "is_adult": True,
    "marks":94.4
}
print(info)