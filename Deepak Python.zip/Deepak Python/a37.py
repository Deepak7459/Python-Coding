# Write a program to separate the following string into coma (,) separeted values.
a = "OOTD . YOLO . ASAP . BRB . CTG . OTW"

b = a.split(".")
print(b)


# Write a program to sort strings alphabetically in python.
a = input("Enter anything here:")
b = sorted(a)
print(b)


# Write a program to remove a given charector from a string.
a = "hello"
b = a.replace("e"," ")
print(b)


