# Sets Function in Python.
a = {"Ironman","Hulk","Thor","Capton America"}
# add.
a.add("Spiderman")
print(a)


# Pop.
a.pop()
print(a)

# Discard.
a.discard("Hulk")
print(a)

# Copy.
a.copy()
print(a)

