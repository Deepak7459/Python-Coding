# Creation of Module.
import a72demo
a = a72demo.add(13,25)
print(a)


b = a72demo.employee["Name"]
print(b)