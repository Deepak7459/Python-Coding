# Conversion of TUple and Tuple Function.
a = ("Oneplus","vivo","opo","Redmi")
print("Before the conversion",type(a))
a = list(a)
print("after the conversion",type(a))
a.append("Realme")
print(a)
a = type(a)
print(type(a))
print(a)






a = ("one plus","vivo","redmi","oppo","samsung")
print(a.count("Redmi"))
print(a.index("opo"))
print("The index of opo is",a.index("opo"))