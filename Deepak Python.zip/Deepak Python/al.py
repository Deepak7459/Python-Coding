# WAP to print the length of a list .(list is the parametre)

cities = ["delhi", "gurgaon","noida","pune","shimla"]
heroes = ["ironman","hulk","thor","captain america"]

def print_len(list):
    print(len(list))
    
    
    print_len(cities)
    print_len(heroes)