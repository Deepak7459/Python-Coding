name=input("enter name")
age=input("enter age")
marks=input("enter marks")

print("welcome",name)
print("age",age)
print("marks",marks)