n = 7
for i in range(1,11):
    print(n,"x",i,"=",n*i)
    #      or
n = int(input("Enter the nummber you want to multiply:"))
for i in range (1,11):
    print(n,"x",i,"=",n*i)