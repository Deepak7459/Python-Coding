#figure out a way to store 9 and 9.0 as separate values in the set .
#(You can take help of built in data types)
values={"9","9.0"}
print(values)