#print numbers from 100 to 1.
i=100
while i>=1:
    print(i)
    i-=1