# For Loop with conditional statement.
for i in range(1,11):
   if i ==3:
    print("add this song to the favs")
else:
    print(i)
    
    
    
    #                      Or
for i in range(1,100):
    if i%8==0 and i%12==0:
        print(i)
        
        
        
    #                    Or
n = 1
while n<=3:
    if n == 3:
        print("addthis to favs")
else:
    print(n)
n += 1     