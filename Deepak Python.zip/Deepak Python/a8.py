# Write a program to check whether a number is odd or even.
num = int(input("Enter the number here :"))
if num % 2 == 0:
    print("it is an even number :")
else:
    print("it is an odd number")