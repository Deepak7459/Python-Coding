def add(x,y):
    return(x+y)




employee={"Name":"Deepak","Age":23,"Gender":"Male"}