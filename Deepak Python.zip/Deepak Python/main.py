# comment,Escape sequence.
# '''ka use bhi ham comment ke liye krte hae .
'''
Hey Dont remove this line 
Course: 100 days of code
'''
# \n ka use new line comment krne ke liye krtehae .
# for comment we use ctrl+/.
print("Hey I am deepak \nand i am good student")

print("Hello World")
# This is a single line comment.
print("This is a statement.")
print("Hello World !!!") # Printing Hello World
# double line comment ya double underscore ke liye ham \" ka use krte hae.
print("Hello I am \"Deepak \"\nand I am a good student in our college ")



print("Hey",6,7,sep="~",end="009\n")# sep is a seperator use for seperate the value and end is use for end the value.
print("deepak")



