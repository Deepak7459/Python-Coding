a = "Harry potter and the goblet of fire"
print(a)

# To find the length of the String.
print(len(a))

# TO find the number of times a charector is occuring .
print(a.count("t"))

# To convert each letter into upper case.
print(a.upper())


# To convert each letter into lower case.
print(a.lower())


# To find the index of any charector.
print(a.index("o"))


# To convert the first letter to capital.
print(a.capitalize())

# To converta string into lower case.
print(a.casefold())

# To write variables inside astring.
name = "Deepak Singh"
age= "23"
b = "my name is {} and my age is {}"
print(b.format(name,age))

# It fills the given charecters and centralizes a string.

print(name.center(23,"*"))