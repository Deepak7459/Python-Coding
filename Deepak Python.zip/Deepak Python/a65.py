# Return Statement.
def hello():
    return("Hello World")
print(hello())


def add(a,b):
    return("The addition of two numbers is",a+b)
print(add(12,14))

# Recursion in Python.
def fact(n):
    if n == 1:
        return 1
    else:
        return(n*fact(n-1)) 
print(fact(5))



# Lambda Function in Pyhon.
a = lambda b: b*5
print(a(4))

x = lambda a,b,c:(a+b)*c
print(x(3,7,3))

# Local variables:
x= 24
print("Firs variable x",x)
def hello():
    x = 25
    return x
print(hello())
print(x)



# Global Variables.
x = 24
print("First variable x",x)
def hello():
    global x
    x = 25
    return x
print(hello())
print(x)