#print the element of the following list usinga loop.
#[1,4,9,16,25,36,49,64,81,100]

nums = [1,4,9,16,25,36,49,64,81,100]

for el in nums:
    print(el)