# Constructor.
class Student:
    
   def _init_(self,fullname):
     self.name = fullname
     print("adding new  student in database..")
     
     
s1 = Student("karan")
print(s1.name)

s2 = Student("deepak")
print(s2.name)