# Slicing and iteration in tuples.
a = ("one plus","vivo","redmi","oppo","samsung")
print(a[1:3])
print(a[ :3])
print(a[2 : ])
print(a[ : : 2])
print(a[1 : : 2])
print(a[: : -1])
print(a[2 : : -1])
for i in a:
    print(i)