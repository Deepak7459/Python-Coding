# Write a Program to create area calculator.
print("**** AREA CALCULATOR ****")
print("""press 1 to get the area of squre
      press 2 to get the area of rectangle
      press 3 to get the area of circle
      press 4 to get the area of triangle""")
choice = int(input("Enter a number between 1 to 4:"))
if choice == 1:
    side = float(input("Enter the length of one side:"))
    area = side **2
    print("The area of the square is:", area) 
    
    
elif choice == 2:
    Length = float(input("Enter the Length of rectangle:"))  
    Width = float(input("Enter the Width of rectangle:"))
    area = Length * Width
    print("The area of the rectangle is:", area)
    
    
elif choice == 3:
    radious = float(input("Enter the radious of circle:"))
    area = 22/7 * radious **2
    print("The area of the circle is:", area)
    
elif choice == 4:
    base= float(input("Enter the base of triangle:"))
    height= float(input("Enter the height of triangle:"))
    area = 0.5 * base * height
    print("The area of the triangle is:", area)
    
else:
    print("Invalid Input")