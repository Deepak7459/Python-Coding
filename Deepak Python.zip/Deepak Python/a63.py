# Write a program tofind difference between two sets.
a = [1,5,6,8,2]
b = [4,5,6,7]
print(a.difference(b))


# Write a python program to remove an item from a set if it is present in the set.
a = [1,5,6,8,2]
a.discard(8)
print(a)