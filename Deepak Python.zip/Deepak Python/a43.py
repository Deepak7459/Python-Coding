# Iteration using for loop with range and length function.
a = ["Hulk","Thor","Ironman","capton America","missmarvel"]
for i in range (len(a)):
    print(a[i])


# iteration using while loop.
i = 0
while i<(len(a)):
    print(a[i])
    i +=1
    
    
# Using short - hand for loop.
[print(i)for i in a]