a=float(input("enter first :"))
b=float(input("enter second :"))
print("average =",(a+b)/2)