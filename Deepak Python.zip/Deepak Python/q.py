#you are a givenalist of subjects for students.Assume one classroom required for 1 subject . How many classroom are needed by all student.



subjects = {
    "python","java","C++","python","javascript","java",
    "python","java","C++","C"
                                                       
}
print(subjects)
print(len(subjects))
