a=int(input("enter first :"))
b=int(input("enter second :"))
print(a >= b)