# Range  function in loops.
'''seq = range(6)

for i in seq:
    print(i)'''
    
    
#for i in range(10):
#    print(i)
''' 
for i in range(2,10):
    print(i)'''
    
'''for i in range (2,10,2):
    print(i)'''
    
    
# foreven numbers .
'''for i in range(2,100,2):
    print(i)'''
    
#for odd numbers.
for i in range(1,100,2):
    print(i)