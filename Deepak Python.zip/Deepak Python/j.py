#Wap to ask the user to enter name of there 3 favourite movies and store them in a list.
movies =[ ]
mov1 = input("enter the first movie :")
mov2 = input("enter the second movie ;")
mov3 = input("enter the third movie :")
movies.append(mov1)
movies.append(mov2)
movies.append(mov3)
print(movies)