# set Function Part - 3.
a = {"Ironman","Hulk","Thor","Captain America"}
b = {"Superman","Batman","Wonder-Women"}
c ={"Hulk","Thor"}

#union.
print(a.union(c))

# Difference.
print(a.difference(c))

# Difference_update.
a.difference_update(c)
print(a)


# Intersection.
x = (a.intersection(c))
print(x)


# Intersection_update.
x = (a.intersection_update(c))
print(x)

# Symetric Difference.
x = a.symmetric_difference(c)
print(x)

# Symmetric_difference update.
x =a.symetric_difference_update(c)
print(x)