side=float(input("enter squre side :"))

print("area=",side*side)