a = "123"
b = 1.23
print(type(a))
print(type(b))
a = int(a)
print("after conversion",type(a))
c = a+b
print(c)
print(type(c))