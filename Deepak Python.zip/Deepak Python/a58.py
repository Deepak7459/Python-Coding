# Sets.
a = {"Ironman","Hulk","Thor","Capton America"}
print(a)
print(type(a))
for x in a:
    print(x)