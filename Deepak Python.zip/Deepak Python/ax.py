# Write a program to display a persion's name , age and adress in three different line .
name = "Deepak Singh"
age = 23
address = "654 lake street"
print(name)
print(age)
print(address)