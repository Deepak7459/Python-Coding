# Write a python function that takes a number as a parameter and check if the number is prime or not.
def check_prime(num):
    if num ==1:
        print("it is not a prime number")
    if num ==2:
        print("it is a prime number")
    if num>2:
        for i in range (2,num):
            if num % i==0:
                print("it is not a prime nummber")
                break
            else:
                print("it is a prime number")
check_prime(11)     