# Whitle Loop.
n = 1
a = int(input("Enter the number here:"))

while n <=10:
    print(a,"x",n,"=",n*a)
    n+=1