# Pretty print folllowing json data.
    # student_data= {"name":"Deepak","age":"23","marks":"80"}


import json
student_data = {"name":"Deepak","age":"23","marks":"80"}
data = json.dumps(student_data , indent = 4 , separators =(",","="))
print(data)