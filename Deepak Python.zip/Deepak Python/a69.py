# Write a python function to sum all the numbers in a list.
def add(numbers):
    total = 0
    for i in numbers:
        total = total + i
        return (total)
    print(add([12,13,15,6,78]))
    
    print("The number of all the list is",add([12,13,15,6,78]))
    
    
    
    
    
    
    #                                OR
    
    def add(numbers):
        if len(numbers)==1:
            print(numbers[0])
        else:
            return((numbers[0])+add(numbers[1:]))    
        print(add([12,13,15,5,78]))